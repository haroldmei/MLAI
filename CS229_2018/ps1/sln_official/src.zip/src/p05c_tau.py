import matplotlib.pyplot as plt
import numpy as np
import util

from p05b_lwr import LocallyWeightedLinearRegression


def main(tau_values, train_path, valid_path, test_path, pred_path):
    """Problem 5(b): Tune the bandwidth paramater tau for LWR.

    Args:
        tau_values: List of tau values to try.
        train_path: Path to CSV file containing training set.
        valid_path: Path to CSV file containing validation set.
        test_path: Path to CSV file containing test set.
        pred_path: Path to save predictions.
    """
    # Load training set
    x_train, y_train = util.load_dataset(train_path, add_intercept=True)

    # *** START CODE HERE ***
    # Search tau_values for the best tau (lowest MSE on the validation set)
    best_tau, best_mse = None, None
    for tau in tau_values:
        clf = LocallyWeightedLinearRegression(tau)
        clf.fit(x_train, y_train)

        x_valid, y_valid = util.load_dataset(valid_path, add_intercept=True)
        p_valid = clf.predict(x_valid)

        plot(x_valid[:, 1:], p_valid, x_train[:, 1], y_train,
             f'output/p05c_tau{tau:.2f}.eps')

        mse = np.mean((p_valid - y_valid) ** 2)
        print('Tau: {}'.format(tau))
        print('MSE: {:g}'.format(mse))

        if best_tau is None or mse < best_mse:
            best_tau = tau
            best_mse = mse

    # Fit a LWR model with the best tau value
    print('Best tau: {} (MSE: {:g})'.format(best_tau, best_mse))
    clf = LocallyWeightedLinearRegression(best_tau)
    clf.fit(x_train, y_train)

    # Run on the test set to get the MSE value
    x_test, y_test = util.load_dataset(test_path, add_intercept=True)
    p_test = clf.predict(x_test)
    mse = np.mean((p_test - y_test) ** 2)
    print('Test MSE: {:g}'.format(mse))
    # Save predictions to pred_path
    np.savetxt(pred_path, p_test)


def plot(x_eval, p_eval, x_train, y_train, save_path):
    plt.figure(figsize=(12, 8))

    # Plot data
    plt.scatter(x_train, y_train, marker='x', c='blue', alpha=.5)
    sorted_idx = np.argsort(x_eval, axis=None)
    plt.scatter(x_eval[sorted_idx], p_eval[sorted_idx],
                marker='o', c='red', alpha=.5)

    plt.savefig(save_path)
    # *** END CODE HERE ***
