import numpy as np
import platform
import json
import os
import sys
import signal
import errno
from functools import wraps

from unittest import TestCase
from gradescope_utils.autograder_utils.decorators import weight, visibility

class HiddenPrints:
    def __enter__(self):
        self._original_stdout = sys.stdout
        sys.stdout = open(os.devnull, 'w')

    def __exit__(self, exc_type, exc_val, exc_tb):
        sys.stdout.close()
        sys.stdout = self._original_stdout

with HiddenPrints():
    import p05_percept
    import p06_spam

from solution import percept_sol
from solution import spam_sol

from collections import defaultdict

EPS = 1e-5

def loadjson(filename):
    with open(filename, 'r') as f:
        return json.load(f)

def timeout(seconds, error_message=os.strerror(errno.ETIME)):
    def decorator(func):
        def _handle_timeout(signum, frame):
            raise TimeoutError(error_message)

        @wraps(func)
        def wrapper(*args, **kwargs):
            if platform.system() == "Windows":
                return func(*args, **kwargs)
            else:
                signal.signal(signal.SIGALRM, _handle_timeout)
                signal.alarm(seconds)
                try:
                    result = func(*args, **kwargs)
                finally:
                    signal.alarm(0)
                return result

        return wrapper

    return decorator

class TestPS2(TestCase):

    def check_numpy_shape(self, filename):
        truth = np.loadtxt("./resources/%s" % filename)
        try:
            submission = np.loadtxt("./output/%s" % filename)
        except:
            print("Couldn't load file: %s. Check that your code runs without errors!" % filename)
            return False
        if submission.shape == truth.shape:
            print("Confirmed your submission is correct: %s" % filename)
            return True
        else:
            print("Improper output file or shape: %s" % filename)
            return False

    def check_json_shape(self, filename):
        truth = loadjson("./resources/%s" % filename)
        try:
            submission = loadjson("./output/%s" % filename)
        except:
            print("Couldn't load file: %s. Check that your code runs without errors!" % filename)
            return False
        if type(truth) == type(submission):
            print("Confirmed your submission is correct: %s" % filename)
            return True
        else:
            print("Improper output file or shape: %s" % filename)
            return False

    def check_numpy_correct(self, filename):
        submission = np.loadtxt("./output/%s" % filename)
        truth = np.loadtxt("./resources/%s" % filename)
        self.assertLess(np.linalg.norm(submission - truth) / len(truth), EPS)

    def check_json_correct(self, filename):
        submission = loadjson("./output/%s" % filename)
        truth = loadjson("./resources/%s" % filename)
        self.assertEqual(submission, truth)

    @weight(0)
    @visibility("visible")
    def test_sanity_check(self):
        checks = [self.check_numpy_shape("p05_dot_predictions"),
                  self.check_numpy_shape("p05_rbf_predictions"),
                  self.check_numpy_shape("p06_naive_bayes_predictions"),
                  self.check_numpy_shape("p06_sample_train_matrix"),
                  self.check_json_shape("p06_dictionary"),
                  self.check_json_shape("p06_top_indicative_words"),
                  self.check_json_shape("p06_optimal_radius"),]
        if all(checks):
            print("Confirmed: all your code runs great! Now get some rest.")
        else:
            print("At least one file had an error. Sorry! :(")
        self.assertTrue(all(checks))

    def train_perceptron(self, kernel, learning_rate, module):
        """Train a perceptron with the given kernel.

        This function trains a perceptron with a given kernel and then
        uses that perceptron to make predictions.
        The output predictions are saved to src/output/p05_{kernel_name}_predictions.txt.
        The output plots are saved to src/output_{kernel_name}_output.pdf.

        Args:
            kernel_name: The name of the kernel.
            kernel: The kernel function.
            learning_rate: The learning rate for training.
        """
        train_x, train_y = percept_sol.util.load_csv('../data/ds5_train.csv')

        state = module.initial_state()

        for x_i, y_i in zip(train_x, train_y):
            module.update_state(state, kernel, learning_rate, x_i, y_i)

        test_x, test_y = percept_sol.util.load_csv('../data/ds5_test.csv')

        predict_y = [module.predict(state, kernel, test_x[i, :]) for i in range(test_y.shape[0])]

        return predict_y

    @weight(1)
    @visibility("after_published")
    @timeout(10)
    def test_q5b_initial_state(self):
        train_x, _ = percept_sol.util.load_csv('../data/ds5_train.csv')

        state = p05_percept.initial_state()

        for x_i in train_x:
            self.assertEqual(1, p05_percept.predict(state, None, x_i), msg="All the predictions should be 1 at the initial state")

    @weight(1)
    @visibility("after_published")
    @timeout(10)
    def test_q5b_zero_learning_rate(self):
        expected = self.train_perceptron(percept_sol.dot_kernel, 0, percept_sol)
        actual = self.train_perceptron(percept_sol.dot_kernel, 0, p05_percept)

        self.assertEqual(expected, actual)

    @weight(1)
    @visibility("after_published")
    @timeout(10)
    def test_q5b_dot_product_predictions(self):
        expected = self.train_perceptron(percept_sol.dot_kernel, 1, percept_sol)
        actual = self.train_perceptron(percept_sol.dot_kernel, 1, p05_percept)

        self.assertEqual(expected, actual)

    @weight(2)
    @visibility("after_published")
    @timeout(10)
    def test_q5b_rbf_predictions(self):
        expected = self.train_perceptron(percept_sol.rbf_kernel, 1, percept_sol)
        actual = self.train_perceptron(percept_sol.rbf_kernel, 1, p05_percept)

        self.assertEqual(expected, actual)

    @weight(1)
    @visibility("after_published")
    @timeout(10)
    def test_q6a_get_words(self):
        example_message = 'the DOG walked Through the park234 ^32141#217? 324s'

        expected = spam_sol.get_words(example_message)

        actual = list(p06_spam.get_words(example_message))

        self.assertEqual(expected, actual)

    def has_unique_indices(self, actual_dictionary):
        words_per_index = defaultdict(list)

        for word, index in actual_dictionary.items():
            words_per_index[index].append(word)

        for i in range(0, len(actual_dictionary)):
            self.assertTrue(len(words_per_index[i]) == 1, msg='There should be a unique word per index')

    @weight(1)
    @visibility("after_published")
    @timeout(10)
    def test_q6a_create_dictionary_partially_correct(self):
        train_messages, _ = spam_sol.util.load_spam_dataset('../data/ds6_train.tsv')
        
        actual_dictionary = p06_spam.create_dictionary(train_messages)

        # We define a partially correct dictionary as one that has unique indices from 0 to the dictionary size
        self.has_unique_indices(actual_dictionary)

    @weight(1)
    @visibility("after_published")
    @timeout(10)
    def test_q6a_create_dictionary_fully_correct(self):
        train_messages, _ = spam_sol.util.load_spam_dataset('../data/ds6_train.tsv')
        
        expected_dictionary = spam_sol.create_dictionary(train_messages, p06_spam.get_words)

        actual_dictionary = p06_spam.create_dictionary(train_messages)

        self.assertTrue(len(expected_dictionary) > 5, msg="The dictionary has at least 5 elements")

        self.has_unique_indices(actual_dictionary)

        actual_words = actual_dictionary.keys()
        expected_words = expected_dictionary.keys()

        self.assertEqual(len(expected_words), len(actual_words), msg='The dictionaries need to be the correct size')

        self.assertEqual(expected_words, actual_words)

    @weight(2)
    @visibility("after_published")
    @timeout(10)
    def test_q6a_transform_text(self):
        train_messages, _ = spam_sol.util.load_spam_dataset('../data/ds6_train.tsv')

        dictionary = p06_spam.create_dictionary(train_messages)
        self.assertTrue(len(dictionary) > 5, msg="The dictionary has at least 5 elements")

        actual_train_matrix = p06_spam.transform_text(train_messages[:100], dictionary)

        expected_train_matrix = spam_sol.transform_text(train_messages[:100], dictionary, p06_spam.get_words)
        
        self.assertTrue(np.array_equal(expected_train_matrix, actual_train_matrix), msg="The matrices must be equal")

    @weight(4)
    @visibility("after_published")
    @timeout(180)
    def test_q6b_correct_predictions(self):

        train_messages, train_labels = spam_sol.util.load_spam_dataset('../data/ds6_train.tsv')
        test_messages, _ = spam_sol.util.load_spam_dataset('../data/ds6_test.tsv')
        
        dictionary = spam_sol.create_dictionary(train_messages, spam_sol.get_words)

        train_matrix = spam_sol.transform_text(train_messages, dictionary, spam_sol.get_words)

        expected_naive_bayes_model1 = spam_sol.fit_naive_bayes_model(train_matrix, train_labels, False)
        expected_naive_bayes_model2 = spam_sol.fit_naive_bayes_model(train_matrix, train_labels, True)
        actual_naive_bayes_model = p06_spam.fit_naive_bayes_model(train_matrix, train_labels)

        test_matrix = spam_sol.transform_text(test_messages, dictionary, spam_sol.get_words)

        expected_naive_bayes_predictions1 = spam_sol.predict_from_naive_bayes_model(expected_naive_bayes_model1, test_matrix)
        expected_naive_bayes_predictions2 = spam_sol.predict_from_naive_bayes_model(expected_naive_bayes_model2, test_matrix)
        actual_naive_bayes_predictions = p06_spam.predict_from_naive_bayes_model(actual_naive_bayes_model, test_matrix)

        # Hack to deal with weird shapes from student submissions
        actual_naive_bayes_predictions = np.squeeze(actual_naive_bayes_predictions)

        is_equal_to_one = (np.array_equal(expected_naive_bayes_predictions1, actual_naive_bayes_predictions) or 
            np.array_equal(expected_naive_bayes_predictions2, actual_naive_bayes_predictions))

        self.assertTrue(is_equal_to_one, msg="The predictions must be equal")

    @weight(3)
    @visibility("after_published")
    @timeout(10)
    def test_q6b_deals_with_underflow(self):
        old_settings = np.seterr(all='raise')
        try:
            train_matrix = np.array([
                [0.0, 1.0],
                [1.0, 0.0],
            ])

            train_labels = np.array([
                0,
                1
            ])

            actual_naive_bayes_model = p06_spam.fit_naive_bayes_model(train_matrix, train_labels)

            test_matrix = np.array([
                [1e20, 1e15],
                [1e15, 1e20],
            ])

            expected_predictions = np.array([
                1,
                0,
            ])

            actual_naive_bayes_predictions = p06_spam.predict_from_naive_bayes_model(actual_naive_bayes_model, test_matrix)

            # Hack to deal with weird shapes from student submissions
            actual_naive_bayes_predictions = np.squeeze(actual_naive_bayes_predictions)

            np.testing.assert_array_equal(expected_predictions, actual_naive_bayes_predictions)
        finally:
            np.seterr(**old_settings)

    @weight(3)
    @visibility("after_published")
    @timeout(10)
    def test_q6b_simple_test_case(self):
        train_matrix = np.array([
            [0.0, 1.0],
            [1.0, 0.0],
        ])

        train_labels = np.array([
            0,
            1
        ])

        actual_naive_bayes_model = p06_spam.fit_naive_bayes_model(train_matrix, train_labels)

        test_matrix = np.array([
            [10, 5],
            [5, 10],
        ])

        expected_predictions = np.array([
            1,
            0,
        ])

        actual_naive_bayes_predictions = p06_spam.predict_from_naive_bayes_model(actual_naive_bayes_model, test_matrix)

        # Hack to deal with weird shapes from student submissions
        actual_naive_bayes_predictions = np.squeeze(actual_naive_bayes_predictions)

        np.testing.assert_array_equal(expected_predictions, actual_naive_bayes_predictions)

    @weight(4)
    @visibility("after_published")
    @timeout(180)
    def test_q6c_correct_words(self):
        train_messages, train_labels = spam_sol.util.load_spam_dataset('../data/ds6_train.tsv')
        
        dictionary = spam_sol.create_dictionary(train_messages, spam_sol.get_words)

        train_matrix = spam_sol.transform_text(train_messages, dictionary, spam_sol.get_words)

        expected_naive_bayes_model = spam_sol.fit_naive_bayes_model(train_matrix, train_labels, False)
        actual_naive_bayes_model = p06_spam.fit_naive_bayes_model(train_matrix, train_labels)

        expected_words = spam_sol.get_top_five_naive_bayes_words(expected_naive_bayes_model, dictionary)
        actual_words = p06_spam.get_top_five_naive_bayes_words(actual_naive_bayes_model, dictionary)

        self.assertEqual(set(expected_words), set(actual_words), msg="The set of words must be correct")

    @weight(1)
    @visibility("after_published")
    @timeout(180)
    def test_q6c_correct_order(self):
        train_messages, train_labels = spam_sol.util.load_spam_dataset('../data/ds6_train.tsv')
        
        dictionary = spam_sol.create_dictionary(train_messages, spam_sol.get_words)

        train_matrix = spam_sol.transform_text(train_messages, dictionary, spam_sol.get_words)

        expected_naive_bayes_model = spam_sol.fit_naive_bayes_model(train_matrix, train_labels, False)
        actual_naive_bayes_model = p06_spam.fit_naive_bayes_model(train_matrix, train_labels)

        expected_words = spam_sol.get_top_five_naive_bayes_words(expected_naive_bayes_model, dictionary)
        actual_words = p06_spam.get_top_five_naive_bayes_words(actual_naive_bayes_model, dictionary)

        self.assertEqual(list(expected_words), list(actual_words), msg="The order of words must be correct")

    @weight(2)
    @visibility("after_published")
    @timeout(300)
    def test_q6d(self):
        train_messages, train_labels = spam_sol.util.load_spam_dataset('../data/ds6_train.tsv')
        val_messages, val_labels = spam_sol.util.load_spam_dataset('../data/ds6_val.tsv')

        train_messages = train_messages[:1000] # run much faster
        
        dictionary = spam_sol.create_dictionary(train_messages, spam_sol.get_words)
        train_matrix = spam_sol.transform_text(train_messages, dictionary, spam_sol.get_words)

        val_matrix = spam_sol.transform_text(val_messages, dictionary, spam_sol.get_words)

        expected_optimal_radius = spam_sol.compute_best_svm_radius(train_matrix, train_labels, val_matrix, val_labels, [0.01, 0.2, 1, 10])
        actual_optimal_radius = p06_spam.compute_best_svm_radius(train_matrix, train_labels, val_matrix, val_labels, [0.01, 0.2, 1, 10])

        self.assertEqual(expected_optimal_radius, actual_optimal_radius)
