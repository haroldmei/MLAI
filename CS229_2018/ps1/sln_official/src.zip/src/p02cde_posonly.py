import numpy as np
import util

from p01b_logreg import LogisticRegression

# Character to replace with sub-problem letter in plot_path/pred_path
WILDCARD = 'X'


def main(train_path, valid_path, test_path, pred_path):
    """Problem 2: Logistic regression for incomplete, positive-only labels.

    Run under the following conditions:
        1. on y-labels,
        2. on l-labels,
        3. on l-labels with correction factor alpha.

    Args:
        train_path: Path to CSV file containing training set.
        valid_path: Path to CSV file containing validation set.
        test_path: Path to CSV file containing test set.
        pred_path: Path to save predictions.
    """
    pred_path_c = pred_path.replace(WILDCARD, 'c')
    pred_path_d = pred_path.replace(WILDCARD, 'd')
    pred_path_e = pred_path.replace(WILDCARD, 'e')

    # *** START CODE HERE ***
    plot_path = pred_path.replace('.txt', '.eps')
    plot_path_c = plot_path.replace(WILDCARD, 'c')
    plot_path_d = plot_path.replace(WILDCARD, 'd')
    plot_path_e = plot_path.replace(WILDCARD, 'e')

    # Part (c): Train and test on true labels
    # Make sure to save outputs to pred_path_c
    x_train, t_train = util.load_dataset(train_path, label_col='t',
                                         add_intercept=True)
    clf = LogisticRegression()
    clf.fit(x_train, t_train)

    x_test, t_test = util.load_dataset(test_path, label_col='t',
                                       add_intercept=True)
    p_test = clf.predict(x_test)
    np.savetxt(pred_path_c, p_test)
    util.plot(x_test, t_test, clf.theta, plot_path_c)

    # Part (d): Train on y-labels and test on true labels
    # Make sure to save outputs to pred_path_d
    x_train, y_train = util.load_dataset(train_path, label_col='y',
                                         add_intercept=True)
    clf = LogisticRegression()
    clf.fit(x_train, y_train)
    x_test, t_test = util.load_dataset(test_path, label_col='t',
                                       add_intercept=True)
    p_test = clf.predict(x_test)
    np.savetxt(pred_path_d, p_test)
    util.plot(x_test, t_test, clf.theta, plot_path_d)

    # Part (e): Apply correction factor using validation set and test on true labels
    x_valid, l_valid = util.load_dataset(valid_path, label_col='y')
    x_valid = x_valid[l_valid == 1, :]  # Restrict to just the labeled examples
    x_valid = util.add_intercept(x_valid)
    y_pred = clf.predict(x_valid)
    alpha = np.mean(y_pred)
    print('Found alpha = {}'.format(alpha))
    x_test, t_test = util.load_dataset(test_path, label_col='t',
                                       add_intercept=True)
    # Plot and use np.savetxt to save outputs to pred_path_e
    np.savetxt(pred_path_e, p_test / alpha)
    util.plot(x_test, t_test, clf.theta, plot_path_e, correction=alpha)
    # *** END CODER HERE
