import matplotlib.pyplot as plt
import numpy as np
import util

from linear_model import LinearModel


def main(tau, train_path, eval_path):
    """Problem 5(b): Locally weighted regression (LWR)

    Args:
        tau: Bandwidth parameter for LWR.
        train_path: Path to CSV file containing dataset for training.
        eval_path: Path to CSV file containing dataset for evaluation.
    """
    # Load training set
    x_train, y_train = util.load_dataset(train_path, add_intercept=True)

    # *** START CODE HERE ***
    # Fit a LWR model
    clf = LocallyWeightedLinearRegression(tau)
    clf.fit(x_train, y_train)

    # Get MSE value on the validation set
    x_eval, y_eval = util.load_dataset(eval_path, add_intercept=True)
    p_eval = clf.predict(x_eval)
    print('Validation MSE: {:g}'.format(np.mean((p_eval - y_eval) ** 2)))

    # Plot validation predictions on top of training set
    # No need to save predictions
    plot_path = 'output/p05b_plot.eps'
    plot(x_eval[:, 1:], p_eval, x_train[:, 1], y_train, plot_path)


def plot(x_eval, p_eval, x_train, y_train, save_path):
    plt.figure(figsize=(12, 8))

    # Plot data
    plt.scatter(x_train, y_train, marker='x', c='blue', alpha=.5)
    sorted_idx = np.argsort(x_eval, axis=None)
    plt.scatter(x_eval[sorted_idx], p_eval[sorted_idx],
                marker='o', c='red', alpha=.5)

    plt.savefig(save_path)
    # *** END CODE HERE ***


class LocallyWeightedLinearRegression(LinearModel):
    """Locally Weighted Regression (LWR).

    Example usage:
        > clf = LocallyWeightedLinearRegression(tau)
        > clf.fit(x_train, y_train)
        > clf.predict(x_eval)
    """

    def __init__(self, tau):
        super(LocallyWeightedLinearRegression, self).__init__()
        self.tau = tau
        self.x = None
        self.y = None

    def fit(self, x, y):
        """Fit LWR by saving the training set.

        """
        # *** START CODE HERE ***
        self.x = x
        self.y = y
        # *** END CODE HERE ***

    def predict(self, x):
        """Make predictions given inputs x.

        Args:
            x: Inputs of shape (m, n).

        Returns:
            Outputs of shape (m,).
        """
        # *** START CODE HERE ***
        if self.x is None or self.y is None:
            raise RuntimeError('Must call fit before predict.')

        y_hat = []
        for x_i in x:
            w_i = self._get_weights(x_i)
            self.theta = self._get_theta(w_i)

            y_hat.append(self.theta.T.dot(x_i))

        y_hat = np.array(y_hat)

        return y_hat

    def _get_weights(self, x):
        """Get LWR weights for an example x."""
        x_diff = x - self.x
        w = np.exp(-np.sum(x_diff ** 2, axis=1) / (2 * self.tau ** 2))
        w = np.diag(w)

        return w

    def _get_theta(self, w):
        """Get theta (linear coefficients) given inputs and weights."""
        x, y = self.x, self.y
        theta = np.linalg.inv(x.T.dot(w).dot(x)).dot(x.T).dot(w).dot(y)

        return theta
        # *** END CODE HERE ***
