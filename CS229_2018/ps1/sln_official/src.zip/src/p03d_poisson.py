import numpy as np
import util

from linear_model import LinearModel


def main(lr, train_path, eval_path, pred_path):
    """Problem 3(d): Poisson regression with gradient ascent.

    Args:
        lr: Learning rate for gradient ascent.
        train_path: Path to CSV file containing dataset for training.
        eval_path: Path to CSV file containing dataset for evaluation.
        pred_path: Path to save predictions.
    """
    # Load training set
    x_train, y_train = util.load_dataset(train_path, add_intercept=False)

    # *** START CODE HERE ***
    # Fit a Poisson Regression model
    clf = PoissonRegression(step_size=lr)
    clf.fit(x_train, y_train)

    # Run on the validation set, and use np.savetxt to save outputs to pred_path
    x_eval, y_eval = util.load_dataset(eval_path, add_intercept=False)
    p_eval = clf.predict(x_eval)
    np.savetxt(pred_path, p_eval)
    # *** END CODE HERE ***


class PoissonRegression(LinearModel):
    """Poisson Regression.

    Example usage:
        > clf = PoissonRegression(step_size=lr)
        > clf.fit(x_train, y_train)
        > clf.predict(x_eval)
    """

    def fit(self, x, y):
        """Run gradient ascent to maximize likelihood for Poisson regression.

        Args:
            x: Training example inputs. Shape (m, n).
            y: Training example labels. Shape (m,).
        """
        # *** START CODE HERE ***
        m, n = x.shape
        if self.theta is None:
            self.theta = np.zeros(n, dtype=np.float32)

        prev_theta = None
        i = 0
        while prev_theta is None \
                or np.sum(np.abs(self.theta - prev_theta)) > self.eps:
            i += 1
            prev_theta = self.theta
            self._step(x, y)
            if self.verbose and i % 100 == 0:
                print('[iter: {:02d}, theta: {}]'
                      .format(i, [round(t, 5) for t in self.theta]))
        # *** END CODE HERE ***

    def predict(self, x):
        """Make a prediction given inputs x.

        Args:
            x: Inputs of shape (m, n).

        Returns:
            Floating-point prediction for each input, shape (m,).
        """
        # *** START CODE HERE ***
        y_hat = np.exp(x.dot(self.theta))

        return y_hat

    def _step(self, x, y):
        """Perform a single gradient ascent update step."""
        grad = np.expand_dims(y - np.exp(x.dot(self.theta)), 1) * x
        self.theta = self.theta + self.step_size * np.mean(grad, axis=0)
        # *** END CODE HERE ***
